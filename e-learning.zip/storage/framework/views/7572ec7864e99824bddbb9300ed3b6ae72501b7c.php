<?php $__env->startSection('title', 'Homepage | '. env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>

<section class="page-header">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="page-header-content">
              <h1><?php echo e($video->course->trans_name); ?></h1>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="<?php echo e(route('website.index')); ?>">Home</a>
                </li>
                <li class="list-inline-item">/</li>
                <li class="list-inline-item">
                    <?php echo e($video->course->trans_name); ?>

                </li>
              </ul>
            </div>
        </div>
      </div>
    </div>
</section>


  <section class="section-padding course">

    <div class="container">
        <div class="row justify-content-center">


            <div class="col-8">
                <div class="text-right">
                    <form class="mb-4" action="<?php echo e(route('website.video_watched', $video->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-main-2">Complete</button>
                    </form>
                </div>
                <video controls width="100%" src="<?php echo e(asset('uploads/'. $video->path)); ?>"></video>
            </div>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-learning\resources\views/front/video_single.blade.php ENDPATH**/ ?>