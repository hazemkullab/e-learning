<?php $__env->startSection('title', 'Create video'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center">
    <h1>Update : <?php echo e($video->trans_name); ?></h1>

    <a class="btn btn-outline-success" onclick="window.history.back()
    ">Return Back</a>
</div>

<?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mt-4 mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('admin.videos.update', $video->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <?php echo $__env->make('admin.videos.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="col-md-12">
                    <button class="btn btn-info px-5">Update</button>
                </div>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-learning\resources\views/admin/videos/edit.blade.php ENDPATH**/ ?>