<div class="row">
<div class="col-md-6">
    <div class="mb-3">
        <label>English Name</label>
        <input name="name_en" value="<?php echo e(old('name_en', $category->en_name)); ?>" class="form-control" placeholder="English Name" />
    </div>
</div>

<div class="col-md-6">
    <div class="mb-3">
        <label>Arabic Name</label>
        <input name="name_ar" value="<?php echo e(old('name_ar', $category->ar_name)); ?>" class="form-control" placeholder="Arabic Name" />
    </div>
</div>

<div class="col-md-12">
    <div class="mb-3">
        <label>Parent Category</label>
        <select class="form-control" name="parent_id">
            <option value="" selected>Select</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e(($item->id == $category->parent_id) ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->trans_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\e-learning\resources\views/admin/categories/form.blade.php ENDPATH**/ ?>