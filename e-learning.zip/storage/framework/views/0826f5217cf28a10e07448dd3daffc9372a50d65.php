<?php $__env->startSection('title', 'Homepage | '. env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>

<section class="page-header">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="page-header-content">
              <h1><?php echo e($title); ?></h1>
              <ul class="list-inline mb-0">
                <li class="list-inline-item">
                  <a href="<?php echo e(route('website.index')); ?>">Home</a>
                </li>
                <li class="list-inline-item">/</li>
                <li class="list-inline-item">
                    <?php echo e($title); ?>

                </li>
              </ul>
            </div>
        </div>
      </div>
    </div>
</section>


  <section class="section-padding course">

    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <?php echo $__env->make('front.sections.course', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


        <div class="row">
            <div class="col-lg-12 blog-pagination text-center">
                

                <?php echo e($courses->links()); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-learning\resources\views/front/courses.blade.php ENDPATH**/ ?>