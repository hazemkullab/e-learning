	type

<div class="row">
<div class="col-md-6">
    <div class="mb-3">
        <label>English Name</label>
        <input name="name_en" value="<?php echo e(old('name_en', $video->en_name)); ?>" class="form-control" placeholder="English Name" />
    </div>
</div>



<div class="col-md-6">
    <div class="mb-3">
        <label>Arabic Name</label>
        <input name="name_ar" value="<?php echo e(old('name_ar', $video->ar_name)); ?>" class="form-control" placeholder="Arabic Name" />
    </div>
</div>

<div class="col-md-12">
    <div class="mb-3">
        <label>Video</label>
        <input type="file" name="path" class="form-control">
        <?php if($video->path): ?>
        <video width="400" src="<?php echo e(asset(('uploads/'.$video->path))); ?>" controls></video>
        <?php endif; ?>
    </div>
</div>

<div class="col-md-12">
    <div class="mb-3">
        <label>Type</label> <br>
        <label><input type="radio" checked name="type" value="paid"> Paid</label> <br>
        <label><input type="radio" onclick="return confirm('Are you sure?')" name="type" value="free"> Free</label>
    </div>
</div>

<div class="col-md-12">
    <div class="mb-3">
        <label>Course</label>
        <select class="form-control" name="course_id">
            <option value="" selected>Select</option>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e(($item->id == $video->course_id) ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->trans_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\e-learning\resources\views/admin/videos/form.blade.php ENDPATH**/ ?>