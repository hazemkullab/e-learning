<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\e-learning\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>