<?php
return [
    'Categoris' => 'Categoris بالاسباني'
];
