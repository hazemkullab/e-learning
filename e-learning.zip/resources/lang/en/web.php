<?php
return [
    'Categoris' => 'Our Categories',
    'search' => 'Search',
    'home' => 'Home',
    'About' => 'About',
    'Courses' => 'Courses',
    'Shop' => 'Shop',
    'Pages' => 'Pages',
    'Contact' => 'Contact',
    'Blog' => 'Blog',
    'Languages' => 'Languages',
    'Login' => 'Login',
];
