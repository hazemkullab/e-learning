<?php
return [
    'Categoris' => 'الاقسام',
    'search' => 'بحث',
    'home' => 'الرئيسية',
    'About' => 'من نحن',
    'Courses' => 'الدورات التدريبية',
    'Shop' => 'المتجر',
    'Pages' => 'الصفحات',
    'Contact' => 'اتصل بنا',
    'Blog' => 'المدونة',
    'Languages' => 'اللغات',
    'Login' => 'دخول',
];
