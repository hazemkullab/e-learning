@extends('admin.master')

@section('title', 'Admin Area | ' . env('APP_NAME'))

@section('content')


<h1>
    Admin Main Area
</h1>


@stop
